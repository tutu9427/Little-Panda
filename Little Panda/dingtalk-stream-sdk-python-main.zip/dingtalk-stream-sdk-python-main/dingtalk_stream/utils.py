# -*- coding:utf-8 -*-

import os

DINGTALK_OPENAPI_ENDPOINT = os.getenv(
    "DINGTALK_OPENAPI_ENDPOINT", "https://api.dingtalk.com"
)

